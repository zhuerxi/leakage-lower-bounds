# Leakage Lower Bounds in Selective Image Encryption — Reproduction Package

This archive contains the MATLAB source code, the standard test set, the raw
experimental outputs and the manuscript source for

> E. Zhu, "Leakage Lower Bounds in Selective Image Encryption: The Encryption
> Ratio Is Not a Security Metric."

It reproduces every table and figure of Section V (Experiments) and the two
appendices of the paper. No proprietary data and no GPU are required.

---

## 1. Requirements

| Item | Version used | Notes |
|---|---|---|
| MATLAB | R2025b | R2021b or later should work; no toolbox function added after R2021b is used |
| Image Processing Toolbox | — | `imread`, `rgb2gray`, `imresize`, `medfilt2`, `conv2`, `exportgraphics` |
| Statistics Toolbox | — | `quantile`, `discretize`, `corr` (Spearman) |
| Hardware | single CPU core | total runtime ≈ 11 min for the full pipeline |

The test images `cameraman`, `circuit`, `rice`, `moon`, `trees`, `indiancorn`,
`printedtext` and `football` are read directly from the MATLAB installation
(`toolbox/images/imdata`). No image files need to be downloaded; the six
remaining images are synthesised in code.

---

## 2. Directory layout

```
leakage-lower-bounds/
  lib/   testset_standard.m    standard test set (14 images, 256x256 uint8)
         mutual_info_est.m     non-parametric MI estimate
                               (equal-frequency histogram + permutation test)
  exp/   run_thm6_leakage.m    Sec. V-A  mask comparison  (E1)
                               Sec. V-B  leakage versus r  (E2)
                               Sec. V-C  bound comparison  (E3)
         run_thm7_duality.m    Sec. V-D  Lipschitz constants and the
                               robustness-sensitivity frontier (E1-E3)
         make_figs_en.m        regenerates the English-labelled figures
                               from the cached MAT files
  out/   *.csv / *.mat         raw outputs of the run
         *.txt                 console logs of the run
         en/                   English-labelled figures used in the paper
  paper/ main.tex, main.pdf    the manuscript
```

All paths inside the scripts are resolved relative to the location of the
script (`mfilename('fullpath')`), so the archive can be unpacked anywhere and
run without editing.

---

## 3. Reproduction

From the archive root, in MATLAB:

```matlab
addpath('lib','exp');
run_thm6_leakage();     % tables: thm6_leakage.csv, thm6_ratio_curve.csv,
                        %         thm6_bound_check.csv  + fig_thm6
run_thm7_duality();     % tables: thm7_lipschitz.csv, thm7_tradeoff.csv,
                        %         thm7_coupling.csv     + fig_thm7
```

or in one line from the shell:

```bash
matlab -batch "addpath('lib','exp'); run_thm6_leakage(); run_thm7_duality();"
```

The English-labelled figures in `out/en/` are regenerated with

```matlab
make_figs_en()          % reads the cached MAT files; requires the MATLAB
                        %   installation to be in place (paper1/paper2 paths
                        %   are also touched by this script)
```

**Staged execution.** `run_thm6_leakage` accepts a stage argument so that a
long job can be resumed:

| call | effect |
|---|---|
| `run_thm6_leakage(1)` | E1 (mask comparison) only |
| `run_thm6_leakage(2)` | E2 (leakage versus r) and E3 (bound) only |
| `run_thm6_leakage(3)` | figures only, from cached outputs |
| `run_thm6_leakage()`  | all three stages |

---

## 4. What each experiment does

### `run_thm6_leakage` — leakage of selective encryption

The encryption model is the one of Section II: the encrypted region `X_e` is
replaced by uniform random values (an ideal permutation, all information
destroyed), the unencrypted region `X_u` is left verbatim. The adversary is
*neighbourhood-mean reconstruction*: it estimates every encrypted pixel by the
3×3 mean of the visible (unencrypted) pixels around it. Leakage is the mutual
information between the adversary's reconstruction and the original image.

* **E1 — mask comparison at fixed `r = 0.20`.** Four region-selection
  strategies are applied to all fourteen images: S1 random scatter, S2
  top-left block, S3 centre block, S4 row-by-row raster. Output:
  `thm6_leakage.csv`.
* **E2 — leakage versus `r`.** For the first eight images, `r` is swept over
  `{0.05, 0.10, 0.20, 0.35, 0.50, 0.70, 0.90, 0.99}` under the random-scatter
  mask. Output: `thm6_ratio_curve.csv`.
* **E3 — comparison against the lower bound.** With `r = 0.20`, the measured
  leakage is compared with the bound `H(X_u) − I(X_u; X_e)`. The term
  `I(X_u; X_e)` is estimated from **cross-boundary adjacent pixel pairs**; using
  random pairs instead destroys the spatial correlation and drives the estimate
  to zero, which would make the bound degenerate to the vacuous `H(X_u)`.
  Output: `thm6_bound_check.csv`.

### `run_thm7_duality` — robustness–sensitivity duality

* **E1** measures the empirical Lipschitz constant of three decryption
  operators (linear 3×3 mean, hard 16-level threshold, 3×3 median) by Monte
  Carlo over random directions. Output: `thm7_lipschitz.csv`.
* **E2** checks that the robustness distortion `D_R` and the sensitivity `S`
  are governed by the same constant. Output: `thm7_coupling.csv`.
* **E3** sweeps the parameterised family
  `Φ_α(C) = (1−α)·median(C) + α·C`, `α ∈ [0,1]`, and reports the
  robustness–sensitivity frontier and its Spearman correlations. Output:
  `thm7_tradeoff.csv`.

---

## 5. Output files

| File | Contents |
|---|---|
| `thm6_leakage.csv` | E1 leakage of the four masks, per image, and the max/min ratio |
| `thm6_ratio_curve.csv` | E2 leakage versus `r`, per image, plus `H(X)` |
| `thm6_bound_check.csv` | E3 measured leakage, `H(X_u)`, `I(X_u;X_e)`, bound, satisfied flag |
| `thm6_all.mat` | the three tables above, as MATLAB `table` objects |
| `thm7_lipschitz.csv` | empirical `L` at small and large perturbations, per operator |
| `thm7_coupling.csv` | `max D_R`, `max S/‖t‖`, and the measured `L` beside it |
| `thm7_tradeoff.csv` | the `(α, robustness, sensitivity)` frontier |
| `thm7_all.mat` | the three tables above, as MATLAB `table` objects |
| `en/fig6_leakage.*` | manuscript Fig. 6: mask comparison and `r`-curves |
| `en/fig7_duality.*` | manuscript Fig. 7: bound margins and the duality frontier |

### Headline numbers reproduced by this package

Fixed `r = 0.20`: on natural images the four strategies differ by at most a
factor `1.0–1.3`; on the two-level images `checker` and `halfsplit` the ratio
exceeds `10^5` (random scatter leaks `≈0.95–1.00` bit, the block strategies
leak exactly `0.0000`).

`r = 0.99`: mean leakage `0.1162` bit, minimum `0.0764` bit, all eight images
strictly positive — leakage does not vanish as `r → 1`.

Bound comparison: satisfied on `71.4 %` (10/14) of images. The four failures
are `iid_uniform` (no spatial correlation, so the bound degenerates to
`H(X_u) = 7.995` and is vacuous) and `rice`, `indiancorn`, `football` (weak
adversary; the `k`-NN re-estimate of `I(X_u;X_e)` of `2.1–2.6` bit still
leaves a gap, so the shortfall is not a histogram artefact).

Lipschitz constants: linear mean `0.3432`, median `1.0230`, hard threshold
`202.39`. Along the parameter family, Spearman `ρ(α, robustness) = +1.000` and
`ρ(α, sensitivity) = −0.991`.

---

## 6. Reproducibility notes

1. **Determinism.** All randomness is seeded at the top of each driver:
   `rng(20261003)` in `run_thm6_leakage` and `rng(20261004)` in
   `run_thm7_duality`; the test-set synthesiser uses `rng(20260930)`. With the
   same MATLAB release the CSV tables are bit-reproducible.
2. **Mutual-information estimator.** `mutual_info_est` uses equal-frequency
   binning (`nBin = 64` for the leakage measurements, `48` for the bound term)
   and subtracts the mean of a permutation null distribution
   (`nPerm = 60`, or `200` by default) to remove the finite-sample bias that
   would otherwise be mistaken for leakage. The estimator returns a net value
   capped at zero, which is why the `constant` and `checker` rows report
   exactly `0.0000`.
3. **Weak adversary.** The neighbourhood-mean adversary overestimates nothing:
   it is a *lower* bound on the leakage of a stronger, prior-based adversary.
   The reported values should be read in that direction.
4. **Bound tolerance.** E3 uses `tol = max(0.5, 0.1·H(X_u))` bits, the order of
   the estimator's finite-sample error, so that a numerically marginal image is
   not scored as a failure.

---

## 7. Licence

Released under the MIT Licence (`SPDX-License-Identifier: MIT`). The MATLAB
test images are distributed with MATLAB and remain subject to the MathWorks
licence; they are read at run time from the local installation and are not
redistributed here.
