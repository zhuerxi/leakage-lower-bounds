function [Ic, detail] = mutual_info_est(X, Y, nBin, nPerm)
%MUTUAL_INFO_EST  互信息的非参数估计（直方图法 + 置换检验基线）
%
% 用途：论文三的泄露度量。核心量 I(X_u; C) 无法解析求解（自然图像模型的
% 高维相关性），故用双变量直方图法估计，并用置换检验给出"无相关性"零假设
% 下的基线，避免把有限样本偏差误认为真实泄露。
%
% 方法
%   1. 把 X、Y 各自量化为 nBin 级（等频分箱，避免稀疏桶）；
%   2. 统计联合直方图 p(x,y)，由
%        I(X;Y) = Σ p(x,y) log2 [ p(x,y) / (p(x)p(y)) ]
%      得到互信息估计 Î；
%   3. 用 nPerm 次随机置换打破 X-Y 关联，得到零分布 {Î_0}；
%   4. 输出净互信息 Î_net = max(Î − mean(Î_0), 0)，并给出经验 p 值。
%
% 输入
%   X, Y   —— 同长度的向量（或可展平的矩阵）
%   nBin   —— 分箱级数（默认 min(64, round(sqrt(n)/2))）
%   nPerm  —— 置换次数（默认 200）
%
% 输出
%   Ic     —— 净互信息（比特）
%   detail —— struct：.I_raw  .I_nullMean  .I_nullStd  .pValue  .nBin  .n

X = double(X(:)); Y = double(Y(:));
n = numel(X);
if numel(Y) ~= n, error('mutual_info_est:lengthMismatch','X 与 Y 长度须一致'); end
if nargin < 3 || isempty(nBin),  nBin = min(64, max(8, round(sqrt(n)/2))); end
if nargin < 4 || isempty(nPerm), nPerm = 200; end

% ---- 等频分箱 ----
qx = quantile(X, linspace(0,1,nBin+1));  qx = unique(qx);
qy = quantile(Y, linspace(0,1,nBin+1));  qy = unique(qy);
bx = discretize(X, qx);  bx(isnan(bx)) = 1;
by = discretize(Y, qy);  by(isnan(by)) = 1;

I_raw = hist_mi(bx, by);

% ---- 置换检验零分布 ----
I0 = zeros(nPerm,1);
for p = 1:nPerm
    I0(p) = hist_mi(bx, by(randperm(n)));
end
pVal = (sum(I0 >= I_raw) + 1) / (nPerm + 1);

Ic = max(I_raw - mean(I0), 0);

detail = struct();
detail.I_raw      = I_raw;
detail.I_nullMean = mean(I0);
detail.I_nullStd  = std(I0);
detail.pValue     = pVal;
detail.nBin       = numel(unique(bx));
detail.n          = n;
end

% ----------------------------------------------------------------------
function I = hist_mi(bx, by)
%HIST_MI  由离散标签直接计算经验互信息（比特）
ux = unique(bx);  uy = unique(by);
nx = numel(ux);   ny = numel(uy);
% 映射到 1..nx / 1..ny
[~, ix] = ismember(bx, ux);
[~, iy] = ismember(by, uy);
J = accumarray([ix iy], 1, [nx ny]);       % 联合频数
P = J / sum(J(:));
px = sum(P,2);  py = sum(P,1);
I = 0;
[ri, ci] = find(P > 0);
for t = 1:numel(ri)
    i = ri(t); j = ci(t);
    I = I + P(i,j) * log2(P(i,j) / (px(i)*py(j)));
end
end
