function imgs = testset_standard()
%TESTSET_STANDARD 构建标准测试图像集（灰度，256×256，uint8）
%
% 说明：本函数从 MATLAB 自带 imdata 中选取并裁剪出 8 张标准测试图像，
%       另用程序化方式合成 4 张（含极值直方图、低对比度等边界情形），
%       合计 12 张。合成图的存在是为了覆盖「自然图像」假设不成立的极端情形，
%       用于检验定理在边界条件下的行为。
%
% 返回：imgs —— 1×12 struct 数组，字段：
%       .name   图像名
%       .I      256×256 uint8 灰度图
%       .kind   'natural' | 'synthetic' | 'boundary'

imgs = struct('name',{},'I',{},'kind',{});

% ---------- 一、自然图像（来自 MATLAB imdata） ----------
md = fullfile(matlabroot,'toolbox','images','imdata');
cand = { 'cameraman.tif','cameraman'
         'circuit.tif',  'circuit'
         'rice.png',     'rice'
         'moon.tif',     'moon'
         'trees.tif',    'trees'
         'indiancorn.jpg','indiancorn'
         'printedtext.png','printedtext'
         'football.jpg', 'football' };

for k = 1:size(cand,1)
    fp = fullfile(md, cand{k,1});
    if ~isfile(fp), continue; end
    I = imread(fp);
    if size(I,3) == 3, I = rgb2gray(I); end
    I = im2uint8(I);
    I = crop_or_resize(I, [256 256]);
    imgs(end+1) = struct('name',cand{k,2},'I',I,'kind','natural'); %#ok<AGROW>
end

% ---------- 二、程序化合成图像 ----------
n = 256;
[xx,yy] = meshgrid(1:n,1:n);

% (1) 平滑渐变场：空间相关性最强，用于极限测试泄露上界
G = uint8(255 * ((xx/ n + yy/n)/2));
imgs(end+1) = struct('name','ramp','I',G,'kind','synthetic');

% (2) 二值棋盘：结构极强、直方图仅两个取值（最坏情形）
C = uint8(255 * mod(floor(xx/8)+floor(yy/8),2));
imgs(end+1) = struct('name','checker','I',C,'kind','synthetic');

% (3) 高斯随机纹理：空间相关性最弱（接近理想噪声）
rng(20260930);
N = uint8( round(255*rand(n,n)) );
imgs(end+1) = struct('name','iid_uniform','I',N,'kind','synthetic');

% (4) 低对比度图像：取值集中在极窄区间，用于检验熵估计的下界行为
L = uint8(128 + 8*sin(xx/7) .* cos(yy/11));
imgs(end+1) = struct('name','lowcontrast','I',L,'kind','boundary');

% (5) 常值图像：熵为 0，用于检验退化情形（极值边界）
imgs(end+1) = struct('name','constant','I',uint8(128*ones(n,n)),'kind','boundary');

% (6) 仅两个灰阶的大块分割：模拟 ROI 结构
S = uint8(zeros(n,n)); S(xx>n/2) = 255;
imgs(end+1) = struct('name','halfsplit','I',S,'kind','boundary');

end

% ======================================================================
function J = crop_or_resize(I, sz)
%CROP_OR_RESIZE 统一到指定尺寸：优先中心裁剪，不足则缩放
    if size(I,1) >= sz(1) && size(I,2) >= sz(2)
        r0 = floor((size(I,1)-sz(1))/2) + 1;
        c0 = floor((size(I,2)-sz(2))/2) + 1;
        J = I(r0:r0+sz(1)-1, c0:c0+sz(2)-1);
    else
        J = imresize(I, sz);
    end
end
