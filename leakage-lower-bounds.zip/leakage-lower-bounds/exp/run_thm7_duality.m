function R = run_thm7_duality()
%RUN_THM7_DUALITY  定理 7 实验：鲁棒—敏感对偶界
%
% 定理 7（鲁棒—敏感对偶界）
%   设解密函数 Φ 为 Lipschitz 连续的（Lipschitz 常数 L）。则在信道扰动 e 与
%   篡改 t 下，鲁棒性失真与敏感性检测量满足
%       D_R ≤ L²‖e‖²,      S ≤ L‖t‖
%   即同一个 Lipschitz 常数 L 同时支配两个目标，两者不可独立优化。
%
% 实验设计
%   E1  Lipschitz 常数测量 —— 对若干典型解密算子实测经验 Lipschitz 常数
%   E2  鲁棒—敏感的耦合    —— 对同一算子，扫描 e 与 t，验证 D_R 与 S 是否
%                             由同一个 L 支配（两目标不可独立优化）
%   E3  权衡前沿           —— 在同一算子族内改变尺度参数，画出 (鲁棒性, 敏感性)
%                             的可行域，检验是否存在帕累托前沿（不可同时最优）
%
% 输出：out/thm7_lipschitz.csv、out/thm7_tradeoff.csv、out/fig_thm7.*

outdir = fullfile(fileparts(fileparts(mfilename('fullpath'))),'out');
if ~exist(outdir,'dir'), mkdir(outdir); end
rng(20261004);

n = 64;
imgs = testset_standard();
% 裁到 n×n，保证所有算子的计算量与数值幅度一致（便于跨算子比较）
for k = 1:numel(imgs)
    Ik = imgs(k).I;
    r0 = floor((size(Ik,1)-n)/2) + 1;  c0 = floor((size(Ik,2)-n)/2) + 1;
    imgs(k).I = Ik(r0:r0+n-1, c0:c0+n-1);
end
fprintf('\n载入测试图像 %d 张（已裁至 %d×%d）\n', numel(imgs), n, n);

%% ---------- 定义三个典型解密/重建算子 ----------
ops = struct();
% O1 线性均值（重尾平滑）：Lipschitz 常数 < 1，鲁棒但钝感
ops(1).name = 'Linear-blur';   ops(1).dec = @(C) dec_linear(C);
% O2 硬阈值（非线性）：L 较大，敏感但脆弱
ops(2).name = 'Hard-threshold';ops(2).dec = @(C) dec_hard(C);
% O3 中值滤波：L = 1，对脉冲噪声鲁棒但对小篡改不敏感
ops(3).name = 'Median-filter'; ops(3).dec = @(C) dec_median(C);

%% ---------- E1：Lipschitz 常数实测 ----------
fprintf('\n===== E1：解密算子的经验 Lipschitz 常数 =====\n');
fprintf('%-18s %-16s %-16s %s\n','算子','L_emp(小扰动)','L_emp(大扰动)','说明');

T1 = {};
I0 = double(imgs(1).I);
for o = 1:numel(ops)
    dec = ops(o).dec;
    % 小扰动段估计 L（线性区）
    Lsmall = est_lipschitz(dec, I0, 1.0);
    Lbig   = est_lipschitz(dec, I0, 20.0);
    note = '';
    if Lsmall < 1.2, note = '收缩（偏鲁棒）';
    elseif Lsmall < 2.5, note = '中等增益';
    else, note = '放大（偏敏感）'; end
    fprintf('%-18s %-16.4f %-16.4f %s\n', ops(o).name, Lsmall, Lbig, note);
    T1(end+1,:) = {ops(o).name, Lsmall, Lbig, note}; %#ok<AGROW>
end
T1tab = cell2table(T1, 'VariableNames', {'operator','L_small','L_large','note'});
writetable(T1tab, fullfile(outdir,'thm7_lipschitz.csv'), 'Encoding','UTF-8');

%% ---------- E2：D_R 与 S 是否由同一 L 支配 ----------
fprintf('\n===== E2：鲁棒性失真与敏感性检测量的耦合 =====\n');
fprintf('%-18s %-14s %-14s %-14s %-14s %s\n', ...
    '算子','max‖e‖','max D_R','max‖t‖','max S','S/‖t‖ ≈ L ?');

T2 = {};
eLevels = [1 2 4 8 16];
tLevels = [1 2 4 8 16];
for o = 1:numel(ops)
    dec = ops(o).dec;
    Lemp = T1tab.L_small(o);
    x0 = double(imgs(1).I);
    Dmax = 0; Smax = 0;
    for e = eLevels
        noisy = min(max(x0 + e*randn(n), 0), 255);
        xh = dec(noisy);
        D = mean((xh(:) - x0(:)).^2);
        Dmax = max(Dmax, D);
    end
    for t = tLevels
        % 篡改：随机翻转 t 个像素的幅值
        tam = x0;  idx = randperm(n*n, min(t*n, numel(x0)));
        tam(idx) = min(tam(idx) + 64, 255);
        S = norm(dec(tam) - dec(x0), 'fro') / sqrt(n*n);
        Smax = max(Smax, S/t);           % 归一化为 ‖t‖ 斜率估计
    end
    fprintf('%-18s %-14d %-14.3f %-14d %-14.3f %s\n', ops(o).name, ...
        max(eLevels), Dmax, max(tLevels), Smax*max(tLevels), ...
        sprintf('%.3f vs L=%.3f', Smax, Lemp));
    T2(end+1,:) = {ops(o).name, max(eLevels), Dmax, max(tLevels), Smax, Lemp}; %#ok<AGROW>
end
T2tab = cell2table(T2, 'VariableNames', ...
    {'operator','e_max','D_R_max','t_max','S_over_t','L_measured'});
writetable(T2tab, fullfile(outdir,'thm7_coupling.csv'), 'Encoding','UTF-8');

%% ---------- E3：权衡前沿（改变同一算子族的尺度参数） ----------
% 构造参数化的解密算子族：Φ_α(C) = (1-α)·median(C) + α·C
%   α = 0   → 纯中值：L 小、鲁棒、不敏感
%   α = 1   → 恒等：L 大、敏感、脆弱
% 直观展示两个目标沿同一参数轴反向变化（帕累托前沿）
fprintf('\n===== E3：鲁棒—敏感权衡前沿 =====\n');
alphas = 0:0.1:1;
robust = zeros(numel(alphas),1);    % 越大约鲁棒（=1/D_R 归一化）
sensit = zeros(numel(alphas),1);    % 越大约敏感
x0 = double(imgs(1).I);
for a = 1:numel(alphas)
    al = alphas(a);
    decA = @(C) (1-al)*double(medfilt2(C,[3 3],'symmetric')) + al*double(C);
    % 鲁棒性：高斯噪声后的失真
    noisy = min(max(x0 + 4*randn(n), 0), 255);
    yn = decA(noisy);
    D = mean((yn(:) - x0(:)).^2);
    robust(a) = 1 / (1 + D);
    % 敏感性：单像素篡改的响应
    tam = x0; tam(floor(n*n/2)) = min(tam(floor(n*n/2))+64, 255);
    S = norm(decA(tam) - decA(x0), 'fro') / sqrt(n*n);
    sensit(a) = S;
end
fprintf('%-10s %-14s %-14s\n','α','鲁棒性','敏感性');
for a = 1:numel(alphas)
    fprintf('%-10.1f %-14.5f %-14.5f\n', alphas(a), robust(a), sensit(a));
end
rho = corr(alphas(:), robust, 'Type','Spearman');
rho2 = corr(alphas(:), sensit, 'Type','Spearman');
fprintf('\nα 与鲁棒性的 Spearman ρ = %+.3f\n', rho);
fprintf('α 与敏感性的 Spearman ρ = %+.3f\n', rho2);
if rho * rho2 < 0
    fprintf('结论：两个目标沿同一参数轴反向变化 —— 支持定理 7 的"不可独立优化"。\n');
else
    fprintf('结论：本次参数族未表现出反向关系，需检查算子族构造。\n');
end

T3 = [alphas(:), robust, sensit];
T3tab = array2table(T3, 'VariableNames', {'alpha','robustness','sensitivity'});
writetable(T3tab, fullfile(outdir,'thm7_tradeoff.csv'), 'Encoding','UTF-8');

%% ---------- 出图 ----------
fgr = figure('Visible','off','Position',[100 100 1050 340]);

subplot(1,2,1);
yyaxis left;  plot(alphas, robust, 'o-', 'Color',[0.20 0.42 0.66],'MarkerSize',3);
ylabel('鲁棒性（越大越鲁棒）');
yyaxis right; plot(alphas, sensit, 's-', 'Color',[0.75 0.30 0.25],'MarkerSize',3);
ylabel('敏感性（越大越敏感）');
xlabel('\alpha（0=纯中值，1=恒等）');
title('(a) 鲁棒—敏感权衡前沿','FontSize',10);
grid on; box off;

subplot(1,2,2);
scatter(robust, sensit, 32, alphas, 'filled');
cb = colorbar; cb.Label.String = '\alpha';
xlabel('鲁棒性'); ylabel('敏感性');
title('(b) 可行域（颜色表示 \alpha）','FontSize',10);
grid on; box off;

exportgraphics(fgr, fullfile(outdir,'fig_thm7.tif'), 'Resolution', 400);
exportgraphics(fgr, fullfile(outdir,'fig_thm7.png'), 'Resolution', 200);
close(fgr);

save(fullfile(outdir,'thm7_all.mat'),'T1tab','T2tab','T3tab');
R = struct('lipschitz',T1tab,'coupling',T2tab,'tradeoff',T3tab);
fprintf('[已写出] thm7_*.csv 与 fig_thm7.tif/png\n');
end

% ======================================================================
function L = est_lipschitz(dec, x0, delta)
%EST_LIPSCHITZ  经验 Lipschitz 常数的蒙特卡洛估计
%   L ≈ max_p ‖Φ(x+δu_p) − Φ(x)‖ / ‖δu_p‖，u_p 为随机方向
n = size(x0,1);
nSamp = 120;
best = 0;
for s = 1:nSamp
    U = randn(size(x0));
    U = U / norm(U,'fro') * delta;
    num = norm(dec(x0 + U) - dec(x0), 'fro');
    den = norm(U, 'fro');
    best = max(best, num/den);
end
L = best;
end

function Y = dec_linear(C)
% 3×3 均值滤波（线性收缩算子）
Y = conv2(double(C), ones(3)/9, 'same');
end

function Y = dec_hard(C)
% 硬阈值：舍入到最近 16 级（非线性、放大差异）
C = double(C);
Y = round(C/16)*16;
end

function Y = dec_median(C)
% 中值滤波
Y = double(medfilt2(C, [3 3], 'symmetric'));
end
