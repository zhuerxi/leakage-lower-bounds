function make_figs_en()
% MAKE_FIGS_EN  由已保存的实验数据重绘英文标注插图（论文插图用，无总标题）
% 运行： cd matlab && matlab -batch "make_figs_en()"
% 输出： paper{1,2,3}/out/en/*.png(.tif)

root = fileparts(mfilename('fullpath'));
mk = @(p) (exist(p,'dir')==7) || mkdir(p);
fs = 9; ft = 9;

%% ================= 论文一 图1：三路径 + 约束压缩 =================
p1 = fullfile(root,'paper1'); out = fullfile(p1,'out','en'); mk(out);
S = load(fullfile(p1,'out','thm5_all.mat'));
T1 = S.T1tab; T3 = S.T3tab;
q = @(nm) T3.bits(find(strcmp(T3.quantity, nm),1));

f = figure('Visible','off','Position',[100 100 1000 330]);
subplot(1,2,1);
V = [T1.H_float_bits, T1.H_period_bits, T1.H_dist_bits];
b = bar(V,'grouped');
b(1).FaceColor=[0.20 0.42 0.66]; b(2).FaceColor=[0.83 0.53 0.18]; b(3).FaceColor=[0.30 0.58 0.35];
set(gca,'XTickLabel',{'Logistic','Sine','Tent'},'FontSize',fs);
ylabel('H_{eff} (bit)','FontSize',fs);
legend({'Float-precision','Sequence-period','Distinguishability'},'Location','northwest','FontSize',7);
title('(a) H_{eff} measured by three paths','FontSize',ft); grid on; box off;

subplot(1,2,2);
vals = [q('unconstrained_min'), T1.H_float_bits(1), T1.H_dist_bits(1), q('constrained_acyclic')];
bb = bar(vals,0.55); bb.FaceColor=[0.55 0.25 0.25];
set(gca,'XTickLabel',{'Unconstr.','Float path','Dist. path','Constrained'},'FontSize',8);
ylabel('H_{eff} (bit)','FontSize',fs);
title('(b) Entropy compression by reversibility','FontSize',ft); grid on; box off;
exportgraphics(f, fullfile(out,'fig1_heff_paths.png'),'Resolution',300);
exportgraphics(f, fullfile(out,'fig1_heff_paths.tif'),'Resolution',400);
close(f);

%% ================= 论文一 图2：审计 =================
A = load(fullfile(p1,'out','audit_all.mat'));
T1 = A.T1tab; T3 = A.T3tab;
imgs = unique(T1.image,'stable');
schemes = unique(T1.scheme,'stable'); ns = numel(schemes);
M = nan(numel(imgs), ns);
for i=1:numel(imgs)
  for j=1:ns
    k = strcmp(T1.image,imgs{i}) & strcmp(T1.scheme,schemes{j});
    if any(k), M(i,j) = T1.NPCR_mean(find(k,1)); end
  end
end
rho = T3.spearman_rho; pval = T3.p_value;

f = figure('Visible','off','Position',[100 100 1000 340]);
subplot(1,2,1);
hb = bar(1:numel(imgs), M, 0.9);
cols = [0.72 0.72 0.72; 0.83 0.53 0.18; 0.20 0.42 0.66];
for c=1:ns, hb(c).FaceColor = cols(mod(c-1,3)+1,:); end
set(gca,'XTick',1:numel(imgs),'XTickLabel',imgs,'FontSize',6.5); xtickangle(45);
hold on; plot([0.5 numel(imgs)+0.5],[0.9961 0.9961],'--','Color',[0.1 0.1 0.1],'LineWidth',0.8); hold off;
ylabel('NPCR','FontSize',fs); ylim([0 1.08]);
legend([{'XOR only','Row diffuse','Full diffuse'},{'Ideal 0.9961'}],'Location','southeast','FontSize',7);
title('(a) NPCR stability across 14 images','FontSize',ft); grid on; box off;

subplot(1,2,2);
ents = [8 16 52];
mnpcr = mean(M,1,'omitnan');
hold on;
scatter(ents, mnpcr, 60, [0.20 0.42 0.66],'filled');
xx = linspace(0,60,50); pp = polyfit(ents, mnpcr, 1);
plot(xx, polyval(pp,xx),'--','Color',[0.62 0.62 0.62],'LineWidth',0.9);
hold off;
xlabel('Nominal key-space (bit)','FontSize',fs); ylabel('Mean NPCR','FontSize',fs);
ylim([0 1.08]); grid on; box off;
title(sprintf('(b) NPCR vs key-space: \\rho = %+.3f (p = %.3f)', rho, pval),'FontSize',ft);
exportgraphics(f, fullfile(out,'fig2_audit.png'),'Resolution',300);
exportgraphics(f, fullfile(out,'fig2_audit.tif'),'Resolution',400);
close(f);
fprintf('[paper1] fig1 fig2 done\n');

%% ================= 论文二 图3：判据三分类 =================
p2 = fullfile(root,'paper2'); out = fullfile(p2,'out','en'); mk(out);
V = load(fullfile(p2,'out','thm1_verdict.mat'));
T = V.T; cnt = V.cnt;
% verdict 为英文键；建立显示名映射（英文插图）
catkey = {'A_reversible','B_irreversible','C_extra_channel'};
catlbl = {'A reversible','B irreversible','C extra channel'};
kinds = unique(T.mediator_kind,'stable');
kindlbl = {'Invariant statistic','Spatial structure','Hash / learned feature'};

f = figure('Visible','off','Position',[100 100 1000 330]);
subplot(1,2,1);
hb = bar(cnt,0.55); hb.FaceColor=[0.20 0.52 0.42];
set(gca,'XTickLabel',catlbl,'FontSize',8);
ylabel('Number of schemes','FontSize',fs); ylim([0 max(cnt)*1.25]);
for c=1:numel(cnt), text(c,cnt(c)+0.12,num2str(cnt(c)),'HorizontalAlignment','center','FontSize',8); end
title(sprintf('(a) Classification of %d schemes', height(T)),'FontSize',ft); grid on; box off;

subplot(1,2,2);
Mk = zeros(numel(kinds), numel(catkey));
for i=1:numel(kinds)
  for c=1:numel(catkey)
    Mk(i,c) = sum(strcmp(T.mediator_kind,kinds{i}) & strcmp(T.verdict,catkey{c}));
  end
end
hb2 = bar(1:numel(kinds), Mk, 0.85,'stacked');
colz = [0.20 0.42 0.66; 0.83 0.53 0.18; 0.55 0.25 0.25];
for c=1:numel(catkey), hb2(c).FaceColor = colz(mod(c-1,3)+1,:); end
set(gca,'XTick',1:numel(kinds),'XTickLabel',kindlbl,'FontSize',7); xtickangle(15);
ylabel('Number of schemes','FontSize',fs); ylim([0 max(max(sum(Mk,2)))*1.2 + 0.15]);
legend(catlbl,'Location','northeast','FontSize',6.5);
title('(b) Grouped by mediating quantity','FontSize',ft); grid on; box off;
exportgraphics(f, fullfile(out,'fig3_verdict.png'),'Resolution',300);
exportgraphics(f, fullfile(out,'fig3_verdict.tif'),'Resolution',400);
close(f);

%% ================= 论文二 图4：拓扑可逆性 =================
S = load(fullfile(p2,'out','thm2_all.mat'));
Trev = S.T1tab; Tirr = S.T2tab;
f = figure('Visible','off','Position',[100 100 1000 330]);
subplot(1,2,1);
% 无环: 5/5 拓扑精确复原(误差恒 0); 含环: L=3,4,5 穷举 + L=8 抽样 2000, 共 2150, 0 次成功
rate = [100, 0];            % 成功复原率 (%)
hb = bar(rate, 0.45);
hb.FaceColor = 'flat';
hb.CData(1,:) = [0.20 0.52 0.42];
hb.CData(2,:) = [0.55 0.25 0.25];
set(gca,'XTickLabel',{'Acyclic','Cyclic'},'FontSize',8);
ylabel('Exact recovery (% of trials)','FontSize',fs); ylim([0 118]);
text(1, 103, '5/5 topologies','HorizontalAlignment','center','FontSize',7.5);
text(2, 3, sprintf('0 / 2150 orders'),'HorizontalAlignment','center','FontSize',7.5,'Color',[1 1 1]);
title('(a) Exact recovery vs topology','FontSize',ft); grid on; box off;

subplot(1,2,2);
semilogy(Tirr.cycleLen, 10.^Tirr.log10Upper,'o-','Color',[0.55 0.25 0.25],'LineWidth',1.2,'MarkerSize',4);
hold on;
for i=1:height(Tirr)
  text(Tirr.cycleLen(i)*1.02, 10.^Tirr.log10Upper(i)*2.2, ...
    sprintf('10^{%.1f}',Tirr.log10Upper(i)),'FontSize',7,'HorizontalAlignment','left');
end
hold off;
xlabel('Cycle length L','FontSize',fs); ylabel('Search space (orders)','FontSize',fs);
title('(b) Exhaustion complexity 256^L','FontSize',ft); grid on; box off;
exportgraphics(f, fullfile(out,'fig4_topology.png'),'Resolution',300);
exportgraphics(f, fullfile(out,'fig4_topology.tif'),'Resolution',400);
close(f);

%% ================= 论文二 图5：区分优势 =================
S = load(fullfile(p2,'out','thm4_all.mat'));
T1 = S.T1; T3 = S.T3tab;
f = figure('Visible','off','Position',[100 100 1000 330]);
subplot(1,2,1);
hb = bar([T1.adv_deterministic, T1.adv_session_random],'grouped');
hb(1).FaceColor=[0.55 0.25 0.25]; hb(2).FaceColor=[0.20 0.42 0.66];
set(gca,'XTick',1:height(T1),'XTickLabel',T1.image,'XTickLabelRotation',45,'FontSize',6.5);
ylabel('Distinguishing advantage','FontSize',fs); ylim([0 1.18]);
legend({'Deterministic','Session-randomized'},'Location','east','FontSize',7);
title('(a) Advantage across images','FontSize',ft); grid on; box off;

subplot(1,2,2);
hold on;
yl = 1:height(T3);
scatter(T3.sim_diffMean, yl, 26, [0.20 0.42 0.66],'filled');
scatter(T3.sim_sameMean, yl, 26, [0.55 0.25 0.25],'filled');
plot([1 1], [0 height(T3)+1],'--','Color',[0.55 0.25 0.25],'LineWidth',0.9);
hold off;
set(gca,'YTick',yl,'YTickLabel',T3.image,'FontSize',6.5);
xlabel('Normalized cross-correlation','FontSize',fs); xlim([-0.4 1.15]);
legend({'Diff-plaintext pairs','Same-plaintext pairs (=\pm1\sigma)'},'Location','southwest','FontSize',7);
title('(b) Ciphertext pairs fully separable','FontSize',ft); grid on; box off;
exportgraphics(f, fullfile(out,'fig5_advantage.png'),'Resolution',300);
exportgraphics(f, fullfile(out,'fig5_advantage.tif'),'Resolution',400);
close(f);
fprintf('[paper2] fig3 fig4 fig5 done\n');

%% ================= 论文三 图6：区域策略 + r 曲线 =================
p3 = fullfile(root,'paper3'); out = fullfile(p3,'out','en'); mk(out);
S = load(fullfile(p3,'out','thm6_all.mat'));
T1 = S.T1tab; T2 = S.T2tab;
f = figure('Visible','off','Position',[100 100 1020 340]);
subplot(1,2,1);
V = [T1.leak_random, T1.leak_blockTL, T1.leak_blockCT, T1.leak_scan];
hb = bar(V,'grouped');
col4 = [0.72 0.72 0.72; 0.83 0.53 0.18; 0.30 0.58 0.35; 0.55 0.25 0.25];
for c=1:4, hb(c).FaceColor = col4(c,:); end
set(gca,'XTickLabel',T1.image,'FontSize',6.5); xtickangle(45);
ylabel('I(X_u ; C)  (bit)','FontSize',fs);
legend({'S1 random','S2 top-left','S3 center','S4 raster'},'Location','northeast','FontSize',6.5);
title('(a) Leakage by region strategy at fixed r','FontSize',ft); grid on; box off;

subplot(1,2,2);
xs = [0.05 0.10 0.20 0.35 0.50 0.70 0.90 0.99];
show = {'cameraman','moon','indiancorn','iid_uniform'};
cols = [0.20 0.42 0.66; 0.83 0.53 0.18; 0.30 0.58 0.35; 0.55 0.25 0.25];
hold on; hs = [];
for i=1:numel(show)
  k = find(strcmp(T2.image, show{i}),1);
  if isempty(k), continue; end
  ys = T2{k, 3:end};
  hs(end+1) = plot(xs, ys, 'o-','Color',cols(i,:),'LineWidth',1.0,'MarkerSize',3);
end
hold off;
xlabel('Encryption ratio r','FontSize',fs); ylabel('I(X_u ; C)  (bit)','FontSize',fs);
legend(show(1:numel(hs)),'Location','northeast','FontSize',7);
title('(b) Leakage vs encryption ratio','FontSize',ft); grid on; box off;
exportgraphics(f, fullfile(out,'fig6_leakage.png'),'Resolution',300);
exportgraphics(f, fullfile(out,'fig6_leakage.tif'),'Resolution',400);
close(f);

%% ================= 论文三 图7：下界对照 + 对偶 =================
S7 = load(fullfile(p3,'out','thm7_all.mat'));
f = figure('Visible','off','Position',[100 100 1020 340]);
subplot(1,2,1);
% 下界检验：测量值 - 下界的余量（正=满足），按是否满足着色
Tb = S.T3tab;
margin = Tb.I_XuC - Tb.bound;
ok = Tb.satisfied == 1;
hold on;
hb = bar(margin, 0.6); hb.FaceColor = 'flat';
for i=1:numel(margin)
    if ok(i), hb.CData(i,:) = [0.20 0.42 0.66]; else, hb.CData(i,:) = [0.85 0.55 0.55]; end
end
yline(0,'k-','LineWidth',0.8); hold off;
set(gca,'XTickLabel',Tb.image,'FontSize',6.5); xtickangle(45);
ylabel('I(X_u;C) - bound  (bit)','FontSize',fs);
title(sprintf('(a) Bound satisfied: %d/%d images', sum(ok), numel(ok)),'FontSize',ft);
grid on; box off;

subplot(1,2,2);
T3 = S7.T3tab;
yyaxis left;  plot(T3.alpha, T3.robustness,'o-','Color',[0.20 0.42 0.66],'MarkerSize',3,'LineWidth',1.0);
ylabel('Robustness (higher = more robust)','FontSize',fs);
yyaxis right; plot(T3.alpha, T3.sensitivity,'s-','Color',[0.75 0.30 0.25],'MarkerSize',3,'LineWidth',1.0);
ylabel('Sensitivity (higher = more sensitive)','FontSize',fs);
xlabel('\alpha   (0 = pure median, 1 = identity)','FontSize',fs);
title('(b) Robustness-sensitivity frontier','FontSize',ft); grid on; box off;
exportgraphics(f, fullfile(out,'fig7_duality.png'),'Resolution',300);
exportgraphics(f, fullfile(out,'fig7_duality.tif'),'Resolution',400);
close(f);
fprintf('[paper3] fig6 fig7 done\n');
fprintf('\nALL EN FIGURES DONE\n');
end
