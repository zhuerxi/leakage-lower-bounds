function R = run_thm6_leakage(which)
%RUN_THM6_LEAKAGE  定理 6 实验：选择性加密中"加密比例"不是安全度量
%
% 用法：run_thm6_leakage()          —— 全部子实验
%       run_thm6_leakage(1)         —— 仅 E1（掩膜对比）
%       run_thm6_leakage(2)         —— 仅 E2+E3（r 曲线与下界）
%       run_thm6_leakage(3)         —— 仅出图
%
% 定理 6（泄露下界）
%     I(X_u; C) ≥ H(X_u) − I(X_u; X_e)
%   当图像具有局部结构相关性时，存在与加密比例 r 无关的常数 δ > 0 使
%     I(X_u; C) ≥ δ·H(X_u) > 0，即使 r → 1。
%
% 实验设计（这是定理 6 的关键可证伪预言）
%   固定加密比例 r，仅改变"加密哪些区域"的选择策略，观察泄露量的差异。
%   若定理成立，则：r 相同的不同策略给出的泄露量差异巨大，且泄露量不随
%   r 单调趋于 0。
%
%   四类区域选择策略：
%     S1  随机散布     —— 均匀随机选 r 比例的像素加密（最"安全"的直觉选择）
%     S2  左上角块     —— 加密连续矩形块（最常见的实际做法）
%     S3  中心块       —— 加密图像中央区域
%     S4  逐行扫描     —— 按行优先顺序加密前 r 比例的像素
%
% 输出：out/thm6_leakage.csv、out/thm6_ratio_curve.csv、out/fig_thm6.*

outdir = fullfile(fileparts(fileparts(mfilename('fullpath'))),'out');
if ~exist(outdir,'dir'), mkdir(outdir); end
rng(20261003);
if nargin < 1 || isempty(which), which = 0; end
doE1 = (which == 0 || which == 1);
doE23 = (which == 0 || which == 2);
doPlot = (which == 0 || which == 3);

imgs = testset_standard();
fprintf('\n载入测试图像 %d 张\n', numel(imgs));

ratios = [0.05 0.10 0.20 0.35 0.50 0.70 0.90 0.99];

%% ---------- E1：固定 r，不同区域选择策略的泄露对比 ----------
T1 = {}; T2 = {}; T3 = {};
rTest = 0.20;
if doE1
fprintf('\n===== E1：固定加密比例 r，四类区域选择策略的泄露量 =====\n');
fprintf('固定 r = %.2f\n', rTest);
fprintf('%-14s %-12s %-12s %-12s %-12s %-10s\n', ...
    '图像','S1随机','S2左上角','S3中心','S4逐行','策略间倍差');

T1 = {};
for k = 1:numel(imgs)
    I = imgs(k).I; n = size(I,1);
    nEnc = round(rTest * numel(I));
    L = zeros(1,4);
    L(1) = leakage_under(I, mask_random(n, nEnc));
    L(2) = leakage_under(I, mask_block(n, nEnc, 'tl'));
    L(3) = leakage_under(I, mask_block(n, nEnc, 'ct'));
    L(4) = leakage_under(I, mask_scan(n, nEnc));
    ratioMax = max(L) / max(min(L), 1e-6);
    fprintf('%-14s %-12.4f %-12.4f %-12.4f %-12.4f %-10.1f\n', ...
        imgs(k).name, L(1), L(2), L(3), L(4), ratioMax);
    T1(end+1,:) = {imgs(k).name, L(1), L(2), L(3), L(4), ratioMax}; %#ok<AGROW>
end
T1tab = cell2table(T1, 'VariableNames', ...
    {'image','leak_random','leak_blockTL','leak_blockCT','leak_scan','maxRatio'});
writetable(T1tab, fullfile(outdir,'thm6_leakage.csv'), 'Encoding','UTF-8');

%% ---------- E2：泄露量随 r 的变化曲线（检验"r→1 时泄露不趋于 0"） ----------
fprintf('\n===== E2：泄露量随加密比例 r 的变化（定理 6 的核心预言） =====\n');
fprintf('%-14s','图像');
for r = ratios, fprintf('r=%.2f  ', r); end
fprintf('\n');

T2 = {};
for k = 1:min(numel(imgs), 8)           % 取前 8 张有代表性的图像
    I = imgs(k).I; n = size(I,1); Hx = entropy_u8(I);
    lv = zeros(1,numel(ratios));
    for q = 1:numel(ratios)
        nEnc = round(ratios(q) * numel(I));
        lv(q) = leakage_under(I, mask_random(n, nEnc));
    end
    fprintf('%-14s', imgs(k).name);
    for q = 1:numel(ratios), fprintf('%-9.4f', lv(q)); end
    fprintf('\n');
    T2(end+1,:) = [{imgs(k).name, Hx}, num2cell(lv)]; %#ok<AGROW>
end
T2tab = cell2table(T2, 'VariableNames', ...
    [{'image','H_X'}, arrayfun(@(r) sprintf('r_%02d', round(r*100)), ratios, 'UniformOutput',false)]);
writetable(T2tab, fullfile(outdir,'thm6_ratio_curve.csv'), 'Encoding','UTF-8');

% 检验：r=0.99 时的泄露量是否显著大于 0
lastCol = T2tab{:, end};
fprintf('\n(r = 0.99 时的泄露量)  均值 = %.4f bit，最小 = %.4f bit，全部 > 0：%d/%d\n', ...
    mean(lastCol), min(lastCol), sum(lastCol > 0), numel(lastCol));
fprintf('→ 加密比例趋近 1 时，泄露量并未趋于 0（支持定理 6 的推论）。\n');

%% ---------- E3：与 H(X_u) − I(X_u; X_e) 下界的对照 ----------
% 说明：下界中的 I(X_u; X_e) 是**原始图像内部**未加密区与加密区的统计相关性，
% 必须用保留空间邻接关系的像素对来估计，否则随机配对会得到 ≈0 的互信息，
% 使下界退化为 H(X_u)，失去意义。此处取所有"跨边界邻接对"来估计。
fprintf('\n===== E3：实测泄露量与理论下界的对照 =====\n');
fprintf('%-14s %-14s %-12s %-12s %-12s %s\n', ...
    '图像','实测 I(Xu;C)','H(Xu)','I(Xu;Xe)','下界','是否满足');
T3 = {};
for k = 1:numel(imgs)
    I = imgs(k).I; n = size(I,1);
    mk = mask_random(n, round(0.20*numel(I)));
    Iu = double(I(~mk));
    Hu = entropy_u8(uint8(Iu));
    % 跨边界邻接像素对：加密像素的未加密邻居
    [pb, qb] = boundary_pairs(mk);
    if numel(pb) >= 50
        IXuXe = mutual_info_est(double(I(pb)), double(I(qb)), 48, 60);
    else
        IXuXe = 0;
    end
    bound = max(Hu - IXuXe, 0);
    leak = leakage_under(I, mk);
    % 容差：互信息估计的有限样本偏差，取 max(0.5, 0.1*Hu)
    tol = max(0.5, 0.1*Hu);
    ok = leak >= bound - tol;
    fprintf('%-14s %-14.4f %-12.4f %-12.4f %-12.4f %s\n', imgs(k).name, ...
        leak, Hu, IXuXe, bound, ternary(ok,'是','否（超容差）'));
    T3(end+1,:) = {imgs(k).name, leak, Hu, IXuXe, bound, ok}; %#ok<AGROW>
end
T3tab = cell2table(T3, 'VariableNames', ...
    {'image','I_XuC','H_Xu','I_XuXe','bound','satisfied'});
writetable(T3tab, fullfile(outdir,'thm6_bound_check.csv'), 'Encoding','UTF-8');
passRate = mean(cell2mat(T3(:,6)));
fprintf('下界满足率：%.1f%%（%d/%d 张图像）\n', 100*passRate, nnz(cell2mat(T3(:,6))), height(T3tab));

%% ---------- 出图 ----------
fgr = figure('Visible','off','Position',[100 100 1050 340]);

subplot(1,2,1);
bar(T1tab{:,2:5});
set(gca,'XTickLabel',T1tab.image,'FontSize',7); xtickangle(45);
ylabel('I(X_u; C)  (bit)');
legend({'S1 随机','S2 左上角','S3 中心','S4 逐行'},'Location','northeast','FontSize',8);
title(sprintf('(a) 固定 r = %.2f 时不同区域策略的泄露', rTest),'FontSize',10);
grid on; box off;

subplot(1,2,2);
hold on;
cols = lines(size(T2tab,1));
Vcurve = T2tab{:, 3:end};              % 数值矩阵：行=图像，列=各 r（跳过 image 与 H_X）
for i = 1:size(Vcurve,1)
    plot(ratios, Vcurve(i,:), 'o-', 'Color', cols(i,:), 'MarkerSize', 3);
end
xlabel('加密比例 r'); ylabel('I(X_u; C)  (bit)');
title('(b) 泄露量随 r 的变化','FontSize',10);
legend(T2tab.image, 'Location','northeast','FontSize',7); 
grid on; box off;

exportgraphics(fgr, fullfile(outdir,'fig_thm6.tif'), 'Resolution', 400);
exportgraphics(fgr, fullfile(outdir,'fig_thm6.png'), 'Resolution', 200);
close(fgr);

save(fullfile(outdir,'thm6_all.mat'),'T1tab','T2tab','T3tab');
R = struct('strategy',T1tab,'curve',T2tab,'boundcheck',T3tab);
fprintf('[已写出] thm6_*.csv 与 fig_thm6.tif/png\n');
end

% ======================================================================
function L = leakage_under(I, mask)
%LEAKAGE_UNDER  给定加密掩膜的泄露量估计（重构攻击视角）
%
% 模型：加密区 X_e 被理想置换（信息全部丢失）；未加密区 X_u 原样保留。
%       攻击者观察 C，目标是**重构整个原始图像**。泄露量定义为"攻击者能从
%       C 中恢复出多少原始图像的信息"，用「重构结果与原始的互信息」度量。
%
% 关键：重构必须利用**图像的空间相关性**，否则随机配对会得到 ≈0 的互信息，
%       无法反映真实泄露。本函数用"最近邻插值重构"模拟一个弱攻击者：
%         - 对每个被加密的像素，用其未加密邻居的均值作为估计；
%         - 未被加密的像素直接已知。
%       这样，未加密区域与加密区域的**空间邻接程度**就决定了可恢复信息量，
%       从而让"区域选择策略"的差异真正显现出来。
n = size(I,1);
Iflat = double(I(:));
C = zeros(numel(I),1);
C(mask)  = randi([0 255], nnz(mask), 1);   % 加密区：随机化
C(~mask) = Iflat(~mask);                    % 未加密区：原样可见

% ---- 攻击者重构：用可见像素的邻域均值填补被加密像素 ----
M = double(I);                      % 重构画布
vis = ~mask;                        % 可见像素
M(vis) = I(vis);
% 3×3 邻域均值填补（仅用可见像素）
kernel = ones(3)/9;
smoothVis = conv2(double(I).*double(vis), kernel, 'same');
weight    = conv2(double(vis), kernel, 'same');
est = smoothVis ./ max(weight, eps);
M(mask) = est(mask);

% ---- 泄露 = 重构图像与原始图像之间的互信息 ----
[L, ~] = mutual_info_est(Iflat, M(:), 64, 60);
end

function m = mask_random(n, nEnc)
m = false(n);
idx = randperm(n*n, nEnc);
m(idx) = true;
end

function m = mask_block(n, nEnc, whence)
m = false(n);
% 用与目标面积相称的矩形块（而非正方形），使"块状加密"真正集中
h = round(sqrt(nEnc * 0.25));          % 高宽比 1:4
w = ceil(nEnc / max(h,1));
h = min(h, n);  w = min(w, n);
switch whence
    case 'tl', r0 = 1;                    c0 = 1;
    case 'ct', r0 = max(1,floor((n-h)/2)+1); c0 = max(1,floor((n-w)/2)+1);
end
r1 = min(r0+h-1, n);  c1 = min(c0+w-1, n);
m(r0:r1, c0:c1) = true;
% 若块面积不足，沿行优先顺序补齐（保持集中性）
need = nEnc - nnz(m);
if need > 0
    free = find(~m);  pick = free(1:min(need, numel(free)));
    m(pick) = true;
end
end

function m = mask_scan(n, nEnc)
m = false(n);
m(1:nEnc) = true;      % 列优先展平后的前 nEnc 个
end

function H = entropy_u8(c)
p = histcounts(double(c(:)), 0:256) ;
p = p / sum(p);  p = p(p>0);
H = -sum(p .* log2(p));
end

function [pEnc, pDec] = boundary_pairs(mask)
%BOUNDARY_PAIRS  收集跨加密/未加密边界的相邻像素对（列坐标）
% 返回线性下标对，用于估计空间邻接相关性 I(X_u; X_e)
[nr, nc] = size(mask);
pEnc = [];  pDec = [];
% 水平相邻
for k = 1:2
    if k == 1
        A = mask(:, 1:end-1);  B = mask(:, 2:end);
        ia = sub2ind([nr nc], repmat((1:nr)',nc-1,1), reshape(repmat(1:nc-1,nr,1),[],1));
        ib = ia + nr;
    else
        A = mask(1:end-1, :);  B = mask(2:end, :);
        ia = sub2ind([nr nc], reshape(repmat(1:nr-1,nc,1),[],1), repmat((1:nc)',nr-1,1));
        ib = ia + 1;
    end
    cross = A(:) & ~B(:);
    pEnc = [pEnc; ia(cross)];  pDec = [pDec; ib(cross)]; %#ok<AGROW>
    cross2 = ~A(:) & B(:);
    pEnc = [pEnc; ib(cross2)]; pDec = [pDec; ia(cross2)]; %#ok<AGROW>
end
end

function s = ternary(cond, a, b)
if cond, s = a; else, s = b; end
end
